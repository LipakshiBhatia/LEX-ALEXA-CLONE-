//  Application Constants Define Here
module.exports = {
    ROUTES :{
        USER:{
            LOGIN :'/login',
            ADMINPANEL:'/adminpanel',
            FINDURL:'/findurl'
        }
    }
}